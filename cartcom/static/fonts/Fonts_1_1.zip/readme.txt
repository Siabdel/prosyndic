We did not create these fonts. We found them on font websites and have packaged 
them together as a free service to our customers and anyone else that wishes to use 
them. We provide them as-in and can accept no responsibility for any issues arising 
from their use. As far as we are aware all of these fonts are free for non-commercial 
use. Some of them are also free for commercial use. Wherever possible we have 
included any licencing information with the fonts - please read it. If you have any 
questions regarding copyright or what constitutes commercial use you should contact 
the font author, not us.

www.perfecttableplan.com
